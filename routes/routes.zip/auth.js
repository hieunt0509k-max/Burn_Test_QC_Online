// routes/auth.js
const express = require('express');
const { prepare } = require('../database/database');
const { hashPassword, verifyPassword, signToken } = require('../lib/auth');
const { requireAuth } = require('../middleware/auth');

const router = express.Router();

// ---------- Đăng nhập ----------
router.post('/login', (req, res) => {
  try{
    const username = String(req.body?.username || '').trim();
    const password = String(req.body?.password || '');
    if(!username || !password)
      return res.status(400).json({ error: 'Thiếu tài khoản hoặc mật khẩu' });

    const user = prepare('SELECT * FROM users WHERE username = ?').get(username);
    if(!user || !verifyPassword(password, user.password_hash))
      return res.status(401).json({ error: 'Tài khoản hoặc mật khẩu không đúng' });

    const token = signToken(user);
    res.json({
      token,
      user: { id: user.id, username: user.username, role: user.role }
    });
  } catch(err){ res.status(500).json({ error: err.message }); }
});

// ---------- Kiểm tra token còn sống ----------
router.get('/me', requireAuth, (req, res) => {
  const user = prepare('SELECT id, username, role FROM users WHERE id = ?').get(req.user.id);
  if(!user) return res.status(401).json({ error: 'Tài khoản không tồn tại' });
  res.json({ user });
});

// ---------- Đổi mật khẩu ----------
router.post('/change-password', requireAuth, (req, res) => {
  try{
    const oldPw = String(req.body?.old_password || '');
    const newPw = String(req.body?.new_password || '');
    if(newPw.length < 6) return res.status(400).json({ error: 'Mật khẩu mới tối thiểu 6 ký tự' });

    const user = prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
    if(!user) return res.status(401).json({ error: 'Không tìm thấy tài khoản' });
    if(!verifyPassword(oldPw, user.password_hash))
      return res.status(400).json({ error: 'Mật khẩu cũ không đúng' });

    prepare('UPDATE users SET password_hash = ? WHERE id = ?').run(hashPassword(newPw), user.id);
    res.json({ ok: true });
  } catch(err){ res.status(500).json({ error: err.message }); }
});

router.post('/logout', (_req, res) => res.json({ ok: true }));

module.exports = router;