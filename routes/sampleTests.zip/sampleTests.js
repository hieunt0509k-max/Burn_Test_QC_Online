const express = require('express');
const multer = require('multer');
const fs = require('fs');
const path = require('path');
const sharp = require('sharp');
const { prepare, transaction, UPLOADS_DIR } = require('../database/database');
const router = express.Router();

const clean = v => v == null ? '' : String(v).trim();
const sampleDir = path.join(UPLOADS_DIR, 'sample-tests');
fs.mkdirSync(sampleDir, { recursive: true });
function safeFolderPart(v, fallback='NA') {
  const x=clean(v).normalize('NFKC').replace(/[<>:"/\\|?*]+/g,'_').replace(/[\s]+/g,' ').trim().replace(/[. ]+$/g,'');
  return x.slice(0,100) || fallback;
}
function samplePhotoFolder(test) {
  const po=safeFolderPart(test?.po_number,'PO');
  const spec=safeFolderPart(test?.product_name || test?.size,'Quy_cach');
  const dir=path.join(sampleDir, `${po}_${spec}`);
  fs.mkdirSync(dir,{recursive:true});
  return dir;
}
function relativeSampleFile(folder, filename) { return path.relative(sampleDir, path.join(folder, filename)).split(path.sep).join('/'); }

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, sampleDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase() || '.jpg';
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2,8)}${ext}`);
  }
});
const upload = multer({ storage, limits: { fileSize: 30 * 1024 * 1024 }, fileFilter: (_req,file,cb)=>{
  cb(null, /^image\/(jpeg|png|webp|jpg)$/i.test(file.mimetype));
}});

function getOne(id){
  const r=prepare(`SELECT s.*, c.name customer_name, po.po_number FROM sample_burn_tests s
    LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN purchase_orders po ON po.id=s.purchase_order_id WHERE s.id=?`).get(id);
  if(r) r.photos=prepare('SELECT * FROM sample_burn_test_photos WHERE sample_test_id=? ORDER BY slot').all(id);
  return r;
}
router.get('/refs',(req,res,next)=>{try{
  const customers=prepare('SELECT id, name FROM customers ORDER BY name').all();
  const purchase_orders=prepare(`SELECT po.id, po.customer_id, po.po_number, c.name AS customer_name
    FROM purchase_orders po JOIN customers c ON c.id=po.customer_id ORDER BY po.po_number`).all();
  res.json({customers, purchase_orders});
}catch(e){next(e)}});
router.get('/',(req,res,next)=>{try{
  let sql=`SELECT s.*, c.name customer_name, po.po_number, (SELECT COUNT(*) FROM sample_burn_test_photos p WHERE p.sample_test_id=s.id) photo_count
    FROM sample_burn_tests s LEFT JOIN customers c ON c.id=s.customer_id LEFT JOIN purchase_orders po ON po.id=s.purchase_order_id WHERE 1=1`;
  const p=[]; if(req.query.q){sql+=' AND (s.product_code LIKE ? OR s.product_name LIKE ? OR c.name LIKE ? OR po.po_number LIKE ?)'; const q='%'+req.query.q+'%'; p.push(q,q,q,q)}
  sql+=' ORDER BY s.test_date DESC, s.id DESC';
  const rows=prepare(sql).all(...p); res.json(rows);
}catch(e){next(e)}});
router.get('/:id/report.docx',async (req,res,next)=>{try{const { buildSampleReport  } = require('../lib/sampleReport');const buf=await buildSampleReport(Number(req.params.id));res.setHeader('Content-Type','application/vnd.openxmlformats-officedocument.wordprocessingml.document');res.setHeader('Content-Disposition',`attachment; filename*=UTF-8''sample-burn-test-${req.params.id}.docx`);res.send(buf)}catch(e){next(e)}});
router.get('/:id',(req,res,next)=>{try{const r=getOne(req.params.id); if(!r)return res.status(404).json({error:'Không tìm thấy test hàng mẫu'});res.json(r)}catch(e){next(e)}});
router.post('/',(req,res,next)=>{try{
  const product_code=clean(req.body.product_code)||'SAMPLE';
  const id=transaction(()=>{
    const r=prepare(`INSERT INTO sample_burn_tests(customer_id,purchase_order_id,product_code,product_name,size,weight,wick_spec,test_date,tester,note) VALUES(?,?,?,?,?,?,?,?,?,?)`)
      .run(req.body.customer_id?Number(req.body.customer_id):null,req.body.purchase_order_id?Number(req.body.purchase_order_id):null,product_code,clean(req.body.product_name)||null,null,null,clean(req.body.wick_spec)||null,new Date().toISOString().slice(0,10),null,null);
    return Number(r.lastInsertRowid);
  });
  res.status(201).json(getOne(id));
}catch(e){res.status(400).json({error:e.message})}});
router.put('/:id',(req,res,next)=>{try{
  const id=Number(req.params.id); if(!getOne(id))return res.status(404).json({error:'Không tìm thấy test hàng mẫu'});
  const product_code=clean(req.body.product_code)||'SAMPLE';
  prepare(`UPDATE sample_burn_tests SET customer_id=?,purchase_order_id=?,product_code=?,product_name=?,size=?,weight=?,wick_spec=?,test_date=?,tester=?,note=?,updated_at=datetime('now') WHERE id=?`).run(req.body.customer_id?Number(req.body.customer_id):null,req.body.purchase_order_id?Number(req.body.purchase_order_id):null,product_code,clean(req.body.product_name)||null,null,null,clean(req.body.wick_spec)||null,new Date().toISOString().slice(0,10),null,null,id);
  res.json(getOne(id));
}catch(e){res.status(400).json({error:e.message})}});
router.delete('/:id',(req,res,next)=>{try{const r=getOne(req.params.id);if(!r)return res.status(404).json({error:'Không tìm thấy'});prepare('DELETE FROM sample_burn_tests WHERE id=?').run(req.params.id);for(const ph of r.photos||[]){try{fs.unlinkSync(path.join(sampleDir,ph.file_name))}catch(_e){}}res.status(204).send()}catch(e){next(e)}});
router.post('/:id/photos',upload.single('photo'),async (req,res,next)=>{
  let uploadedPath=null, compressedPath=null;
  try{
    const id=Number(req.params.id);
    if(!getOne(id)) throw new Error('Không tìm thấy test hàng mẫu');
    if(!req.file) throw new Error('Chưa chọn ảnh');
    uploadedPath=req.file.path;

    // Luôn nén ảnh phía server để dù chụp từ điện thoại hay tải ảnh gốc lên,
    // file lưu trong uploads vẫn nhỏ, đúng chiều và đồng nhất định dạng JPEG.
    const base=path.basename(req.file.filename,path.extname(req.file.filename));
    const test=getOne(id);
    const photoFolder=samplePhotoFolder(test);
    compressedPath=path.join(photoFolder,`${base}-compressed.jpg`);
    await sharp(uploadedPath,{failOn:'none'})
      .rotate()
      .resize({width:1600,height:1600,fit:'inside',withoutEnlargement:true})
      .jpeg({quality:78,mozjpeg:true})
      .toFile(compressedPath);

    const stat=fs.statSync(compressedPath);
    const requestedSlot=Number(req.body.slot);
    let slot=Number.isInteger(requestedSlot)&&requestedSlot>0?requestedSlot:0;
    if(!slot){
      const used=prepare('SELECT slot FROM sample_burn_test_photos WHERE sample_test_id=? ORDER BY slot').all(id).map(x=>Number(x.slot)).filter(Number.isFinite);
      slot=1;
      const set=new Set(used);
      while(set.has(slot)) slot++;
    }
    const old=prepare('SELECT * FROM sample_burn_test_photos WHERE sample_test_id=? AND slot=?').get(id,slot);
    if(old){
      try{fs.unlinkSync(path.join(sampleDir,old.file_name))}catch(_e){}
      prepare('DELETE FROM sample_burn_test_photos WHERE sample_test_id=? AND slot=?').run(id,slot);
    }
    const storedName=relativeSampleFile(photoFolder,`${base}-compressed.jpg`);
    const fileUrl=`/uploads/sample-tests/${storedName}`;
    prepare(`INSERT INTO sample_burn_test_photos(sample_test_id,slot,file_name,file_url,original_name,mime_type,file_size) VALUES(?,?,?,?,?,?,?)`).run(id,slot,storedName, fileUrl,req.file.originalname,'image/jpeg',stat.size);
    try{if(uploadedPath!==compressedPath)fs.unlinkSync(uploadedPath)}catch(_e){}
    res.status(201).json(getOne(id));
  }catch(e){
    try{if(uploadedPath&&fs.existsSync(uploadedPath))fs.unlinkSync(uploadedPath)}catch(_e){}
    try{if(compressedPath&&fs.existsSync(compressedPath))fs.unlinkSync(compressedPath)}catch(_e){}
    res.status(400).json({error:e.message});
  }
});
router.delete('/:id/photos/:slot',(req,res,next)=>{try{const ph=prepare('SELECT * FROM sample_burn_test_photos WHERE sample_test_id=? AND slot=?').get(req.params.id,req.params.slot);if(!ph)return res.status(404).json({error:'Không tìm thấy ảnh'});prepare('DELETE FROM sample_burn_test_photos WHERE id=?').run(ph.id);try{fs.unlinkSync(path.join(sampleDir,ph.file_name))}catch(_e){}res.status(204).send()}catch(e){next(e)}});
module.exports=router;
